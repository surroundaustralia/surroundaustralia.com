# surround-website-structure
Potential website structure being trialled here in outline


# Suggested structure
* Home
    * Products
        * [SOP](sop.md)
            * [Video](sop-video.md)
            * [Details](sop-details.md)
    * Services
    * Research
        * Internet Standards
        * Semantic Data Management
        * eXplainable AI
    * Customers
        * Current Projects
        * Testemonials
    * Partners
    * About Us
        - Out Story
        - Out Team
        - Engagement
    * Contact
        - Form
        - Addresses

**Research**  
Since SURROUND is an R&D-heavy company, it makes sense to advertise our research right at the top level alongside products
