# SOP Video
## Video runsheet

topic | time
--- | ---
brief outline | 15sec
small demo<br />jump to a small Use Case demo first | 1min
full outline | 1min
implementations/testemonials<br />inc. Use Cases | 2min
how to get/use |45sec
**TOTAL** | **5min**
